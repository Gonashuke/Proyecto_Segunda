package Model;

public class productoEmpleados {
    private int id;
    private String nombre;
    private int precio;
    private int puntos;
    private int cantidad;
    private int cantidadNueva;

    public productoEmpleados(String nombre){
        this.setNombre(nombre);
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public int getId() {
        return id;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setPrecio(int precio) {
        this.precio = precio;
    }
    
    public int getPrecio() {
        return precio;
    }
    
    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }
    
    public int getPuntos() {
        return puntos;
    }
    
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    public int getCantidad() {
        return cantidad;
    }
    
    public void setCantidadNueva(int cantidadNueva) {
        this.cantidadNueva = cantidadNueva;
    }
    
    public int getCantidadNueva() {
        return cantidadNueva;
    }
}