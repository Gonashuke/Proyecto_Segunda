package Model;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class conexion {    
    private Connection conexion;
    
    private void abrirConexion() throws SQLException {
        String dbCon = "jdbc:derby://localhost:1527/Proyecto";
        String user = "root";
        String pass = "root";
        conexion = DriverManager.getConnection(dbCon,user,pass);
    }
    
    public void cerrarConexion() throws SQLException{
        conexion.close();
    }
    
    public boolean buscar(autenticacion au)throws Exception {
         
        ResultSet res;
        this.abrirConexion();
        Statement stmt = conexion.createStatement();
        res = stmt.executeQuery("select * from Usuarios where usuario = '"+  au.getUsuario() + "' and contrasena = '" + au.getContrasena() + "'" );       
        
        if(res.next()) {
            return true;
        }
        else {
            return false;
        }   
     }
    
  public int id(autenticacion au)throws Exception {  
        ResultSet res;
        this.abrirConexion();
        Statement stmt = conexion.createStatement();
        res = stmt.executeQuery("select idUsuario from Usuarios where usuario = '"+  au.getUsuario() + "' and contrasena = '" + au.getContrasena() + "'" );       
        
         int id = Integer.parseInt(res.getString("idUsuario"));
          this.cerrarConexion();
         return id;
    }
}