package Model;

public class autenticacion {
    private String usuario;
    private String conrasena;

    
    public autenticacion(String usuario , String contrasena){
        this.setUsuario(usuario);
        this.setContrasena(contrasena);
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContrasena() {
        return conrasena;
    }

    public void setContrasena(String contrasena) {
        this.conrasena = contrasena;
    }
}