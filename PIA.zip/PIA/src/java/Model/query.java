package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class query {
    
    private Connection conexion;
    
    private void abrirConexion() throws SQLException {
        String dbCon = "jdbc:derby://localhost:1527/Proyecto";
        String user = "root";
        String pass = "root";
        conexion = DriverManager.getConnection(dbCon,user,pass);
    }
    
    public void cerrarConexion() throws SQLException {
        conexion.close();
    }
    
    public void insertarProducto(producto producto) throws Exception {
        this.abrirConexion();
        Statement stmt = conexion.createStatement();
        String ap="insert into ROOT.productosclientes values ("+ producto.getId() +",'" + producto.getNombre()+"',"+ producto.getPrecio()+","+ producto.getCantidad()+")";
        stmt.executeUpdate(ap);
        this.cerrarConexion();
    }
    
    public List obb(producto producto)throws Exception{
        ResultSet  res;
        List beans = new ArrayList();
        
        try{
        this.abrirConexion();} catch(SQLException e){}
        Statement stmt = conexion.createStatement();
        res = stmt.executeQuery("select * from ROOT.productosclientes where idProducto = "+producto.getId()+"" );
        
        while(res.next()) {
            
 
            int id = Integer.parseInt(res.getString("idProducto"));
            String nombre = res.getString("NOMBRE");
            int precio = Integer.parseInt(res.getString("PRECIO"));
            int cantidad = Integer.parseInt(res.getString("CANTIDAD"));
            
            
            producto ob1 = new producto(id);
            ob1.setCantidad(cantidad);
            ob1.setNombre(nombre);
            ob1.setPrecio(precio);
            
            beans.add(ob1);
        }
            return beans;
    }
    
   public List obt()throws Exception{
        ResultSet  res;
        List beans = new ArrayList();
        
        try{
        this.abrirConexion();} catch(SQLException e){}
        Statement stmt = conexion.createStatement();
        res = stmt.executeQuery("select * from ROOT.productosclientes ");
        
        while(res.next()) {
            
 
            int id = Integer.parseInt(res.getString("idProducto"));
            String nombre = res.getString("NOMBRE");
            int precio = Integer.parseInt(res.getString("PRECIO"));
            int cantidad = Integer.parseInt(res.getString("CANTIDAD"));
            
            
            producto ob1 = new producto(id);
            ob1.setCantidad(cantidad);
            ob1.setNombre(nombre);
            ob1.setPrecio(precio);
            
            beans.add(ob1);
        }
            return beans;
    }
    
    public void borrar(producto producto) throws Exception {
        
        

        this.abrirConexion();
        Statement stmt = conexion.createStatement();
       stmt.executeUpdate("delete  from ROOT.productosclientes where idProducto = "+producto.getId()+"" );
        
       
      
            
            this.cerrarConexion();
       
       
       
    }
    
    public void actualizar(producto producto) throws SQLException {
        
    this.abrirConexion();
    Statement stmt = conexion.createStatement();
    
    
    String query = "update  ROOT.PRODUCTOSCLIENTES set Cantidad = "+ producto.getCantidadNueva()+" where idProducto = "+producto.getId()+"";
    stmt.executeUpdate(query); 
     
    
   this.cerrarConexion();
    
        
        
        
        
    }
}