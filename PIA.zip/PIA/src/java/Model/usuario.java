package Model;

public class usuario {
    private int idUsuario;
    private int idTipoUsuario;
    private String usuario;
    private String contrasena;
    
    public usuario(){
        
                
    }
    
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
    
    public int getIdUsuario() {
        return idUsuario;
    }
    
    public void setIdTipoUsuario(int idTipoUsuario) {
        this.idTipoUsuario = idTipoUsuario;
    }
    
    public int getIdTipoUsuario() {
        return idTipoUsuario;
    }
    
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    
    public String getUsuario() {
        return usuario;
    }
    
    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
    
    public String getContrasena() {
        return contrasena;
    }
}
