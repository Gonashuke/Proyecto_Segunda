/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.autenticacion;
import Model.conexion;
import Model.producto;
import Model.productoEmpleados;
import Model.query;
import Model.usuario;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class NewServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
         response.setContentType("text/html;charset=UTF-8");
        try {
            HttpSession session = request.getSession();
            String accion = request.getParameter("accion");
            switch(accion){
                case "inicio":
                    response.sendRedirect("index.html");
                    break;
                    
                case "logear":
                    String txtUser = request.getParameter("txt-username");
                    String txtPass = request.getParameter("txt-password");
                    autenticacion au = new autenticacion(txtUser, txtPass);
                    
                    conexion con = new conexion();
                    boolean isValidUser = con.buscar(au);
                    
                    if(isValidUser) {
                        
                       //int a = con.id(au);
                        
                        usuario user = new usuario();
                        //user.setIdTipoUsuario(a);
                        user.setUsuario(txtUser);
                        user.setContrasena(txtPass);
                        
                        session.setAttribute("USUARIO", user.getUsuario());
                        response.sendRedirect("tienda.jsp");}else{response.sendRedirect("tienda.jsp");}
                    break;
                
                case "cerrarsession":
                    session.invalidate();
                    response.sendRedirect("login.jsp");
                    break;
                
                case "iraperfil":
                    response.sendRedirect("tienda.jsp");
                    break;
                
                case "agregarproducto":
                    int id = Integer.parseInt(request.getParameter("id"));
                    String nombre = request.getParameter("nombre");
                    int precio = Integer.parseInt(request.getParameter("precio"));
                    int cantidad = Integer.parseInt(request.getParameter("cantidad"));
                    producto producto = new producto(id);
                    producto.setNombre(nombre);
                    producto.setPrecio(precio);
                    producto.setCantidad(cantidad);
                    query q = new query();
                    try {
                        q.obt();
                        q.insertarProducto(producto);
                        q.obt();
                    }
                    catch(Exception e) {
                    }
                    response.sendRedirect("agregarProducto.jsp");
                    break;
                
                case "buscarProducto":
                    int id1 = Integer.parseInt(request.getParameter("id"));
                    producto productob= new  producto(id1);
                    query qb = new query();
                    try {
                        List lista = qb.obb(productob);;
                        session.setAttribute("comentarios", lista);
                        qb.obt();
                    }
                    catch(Exception e) {
                    }
                    response.sendRedirect("buscarProducto.jsp");
                    break;
                
               case "todo":
                    
                    query qb2 = new query();
                    try {
                        List lista = qb2.obt();
                        session.setAttribute("comentarios", lista);
                    }
                    catch(Exception e) {
                    }
                    response.sendRedirect("buscarProducto.jsp");
                    break;

                
                case "eliminar":
                    int idw = Integer.parseInt(request.getParameter("id"));
                    producto productow= new  producto(idw);
                    query qbw = new query();
                    try {
                        qbw.borrar(productow);
                        
                        List lista = qbw.obt();;
                        session.setAttribute("comentarios", lista);
                        
                    }
                    catch(Exception e) {
                    }
                    response.sendRedirect("eliminarProducto.jsp");
                    break;
                
                case "actualizar":
                    int idaC = Integer.parseInt(request.getParameter("ids"));
                    int nuevacantidadC = Integer.parseInt(request.getParameter("nuevacantidad"));
                    producto productocambioC = new  producto(idaC);
                    productocambioC.setCantidadNueva(nuevacantidadC);
                    
                    query cambiocantidadC = new query();
                    try {
                        cambiocantidadC.actualizar(productocambioC);
                    }
                    catch(Exception e) {
                    }
                    response.sendRedirect("modificarCantidadDeProducto.jsp");
                    break;    
            }
        }
        catch(Exception e){
            response.sendRedirect("error.jsp");
        }
        
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
